# 🎬 Recommendation System

A full-stack **Recommendation System** implementing three collaborative filtering techniques on the **MovieLens-100K** dataset — from classic Matrix Factorization to Neural Collaborative Filtering.

---

## 🧠 Models Implemented

| Model | Technique | Key Idea |
|---|---|---|
| **SVD** | Funk Matrix Factorization (SGD) | Decomposes rating matrix into user & item latent factors with biases |
| **ItemKNN** | Item-based Collaborative Filtering | Recommends based on cosine similarity between item vectors |
| **NCF** | Neural Collaborative Filtering | GMF + MLP branches combined for non-linear interaction modeling |

---

## 📁 Project Structure

```
recommendation-system/
├── notebooks/
│   └── recommendation_system.ipynb  ← Main deliverable (8 sections)
├── src/
│   ├── models.py       # SVD, ItemKNN, NCF implementations
│   ├── data_utils.py   # MovieLens download, loading, splitting
│   ├── metrics.py      # RMSE, MAE, Precision@K, Recall@K, NDCG@K, Hit Rate
│   ├── visualize.py    # Plots: distribution, comparison, PR curve
│   └── main.py         # CLI pipeline (train + evaluate + plot)
├── tests/
│   └── test_models.py  # Pytest unit tests
├── results/            # Auto-generated plots & metrics JSON
├── requirements.txt
├── .gitignore
└── README.md
```

---

## 🚀 Quick Start

### 1. Install dependencies

```bash
git clone https://github.com/<your-username>/recommendation-system.git
cd recommendation-system
pip install -r requirements.txt
```

### 2. Run the Jupyter Notebook (recommended)

```bash
jupyter notebook notebooks/recommendation_system.ipynb
```

The notebook walks through all steps with inline plots and explanations.

### 3. Or run the CLI pipeline

```bash
python src/main.py                          # all models, K=10
python src/main.py --models svd knn         # skip NCF
python src/main.py --k 20 --svd-epochs 30   # custom config
```

---

## 📊 Evaluation Metrics

### Rating Prediction
| Metric | What it measures |
|---|---|
| **RMSE** | Root mean squared error on predicted ratings |
| **MAE** | Mean absolute error on predicted ratings |

### Ranking / Top-N
| Metric | What it measures |
|---|---|
| **Precision@K** | Fraction of top-K recs that are relevant |
| **Recall@K** | Fraction of relevant items found in top-K |
| **NDCG@K** | Ranking quality with position-aware discounting |
| **Hit Rate@K** | % of users with ≥1 relevant item in top-K |

---

## 📈 Typical Results (MovieLens-100K, K=10)

| Model | RMSE | MAE | Precision@10 | NDCG@10 |
|---|---|---|---|---|
| SVD | ~0.92 | ~0.72 | ~0.35 | ~0.38 |
| ItemKNN | ~1.01 | ~0.80 | ~0.31 | ~0.33 |
| NCF | — | — | ~0.33 | ~0.36 |

---

## 🔧 Adapting to Your Own Dataset

1. Prepare a CSV with columns: `user_id`, `item_id`, `rating` (0-indexed integers)
2. Use `load_custom_csv('your_file.csv')` in `data_utils.py`
3. Pass the resulting DataFrame to `train_test_split_ratings()`
4. Everything else works as-is

---

## 📦 Dependencies

- `torch` ≥ 2.1, `numpy`, `pandas`, `scipy`
- `scikit-learn`, `matplotlib`
- `jupyter`, `pytest`

---

## 📄 License

MIT
