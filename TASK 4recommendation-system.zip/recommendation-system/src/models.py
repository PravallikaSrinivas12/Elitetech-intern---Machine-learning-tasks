"""
Recommendation Models
=====================
1. SVD  — classic Matrix Factorization (Funk SVD / SGD)
2. NMF  — Non-negative Matrix Factorization
3. NCF  — Neural Collaborative Filtering (PyTorch)
4. ItemKNN — Item-based Collaborative Filtering (cosine similarity)
"""

import numpy as np
import torch
import torch.nn as nn
from scipy.sparse import csr_matrix
from sklearn.metrics.pairwise import cosine_similarity


# ─────────────────────────────────────────────────────────────
# 1. SVD — Funk Matrix Factorization via SGD
# ─────────────────────────────────────────────────────────────

class SVDRecommender:
    """
    Funk SVD with user/item biases, trained via SGD.

    r_ui ≈ μ + b_u + b_i + p_u · q_i
    """

    def __init__(self, n_factors: int = 50, lr: float = 0.005,
                 reg: float = 0.02, n_epochs: int = 20, random_state: int = 42):
        self.n_factors   = n_factors
        self.lr          = lr
        self.reg         = reg
        self.n_epochs    = n_epochs
        self.random_state = random_state

    def fit(self, ratings: np.ndarray, verbose: bool = True):
        """
        Args:
            ratings: (n_samples, 3) array of [user_id, item_id, rating]
        """
        rng = np.random.default_rng(self.random_state)
        users = ratings[:, 0].astype(int)
        items = ratings[:, 1].astype(int)
        rs    = ratings[:, 2].astype(float)

        self.n_users = users.max() + 1
        self.n_items = items.max() + 1
        self.global_mean = rs.mean()

        self.P  = rng.normal(0, 0.1, (self.n_users, self.n_factors))  # user factors
        self.Q  = rng.normal(0, 0.1, (self.n_items, self.n_factors))  # item factors
        self.bu = np.zeros(self.n_users)   # user biases
        self.bi = np.zeros(self.n_items)   # item biases

        for epoch in range(self.n_epochs):
            idx = rng.permutation(len(ratings))
            total_loss = 0.0
            for i in idx:
                u, it, r = users[i], items[i], rs[i]
                pred = self._predict_one(u, it)
                err  = r - pred
                total_loss += err ** 2

                # update biases
                self.bu[u] += self.lr * (err - self.reg * self.bu[u])
                self.bi[it] += self.lr * (err - self.reg * self.bi[it])

                # update latent factors
                pu_old = self.P[u].copy()
                self.P[u]  += self.lr * (err * self.Q[it] - self.reg * self.P[u])
                self.Q[it] += self.lr * (err * pu_old    - self.reg * self.Q[it])

            rmse = np.sqrt(total_loss / len(ratings))
            if verbose and (epoch + 1) % 5 == 0:
                print(f"  SVD Epoch {epoch+1:>3}/{self.n_epochs}  RMSE={rmse:.4f}")

        return self

    def _predict_one(self, u: int, i: int) -> float:
        return (self.global_mean + self.bu[u] + self.bi[i]
                + self.P[u] @ self.Q[i])

    def predict(self, user_id: int, item_ids: np.ndarray) -> np.ndarray:
        scores = np.array([self._predict_one(user_id, int(i)) for i in item_ids])
        return scores

    def recommend(self, user_id: int, n: int = 10,
                  seen_items: set = None) -> list[tuple[int, float]]:
        all_items = np.arange(self.n_items)
        if seen_items:
            all_items = all_items[~np.isin(all_items, list(seen_items))]
        scores = self.predict(user_id, all_items)
        top_idx = np.argsort(-scores)[:n]
        return [(int(all_items[i]), float(scores[i])) for i in top_idx]


# ─────────────────────────────────────────────────────────────
# 2. Item-based KNN Collaborative Filtering
# ─────────────────────────────────────────────────────────────

class ItemKNNRecommender:
    """Item-based CF using cosine similarity on the user-item matrix."""

    def __init__(self, k: int = 20):
        self.k = k

    def fit(self, ratings: np.ndarray):
        users = ratings[:, 0].astype(int)
        items = ratings[:, 1].astype(int)
        rs    = ratings[:, 2].astype(float)
        self.n_users = users.max() + 1
        self.n_items = items.max() + 1

        self.R = csr_matrix((rs, (users, items)),
                            shape=(self.n_users, self.n_items))
        # item-item cosine similarity  (items × items)
        self.sim = cosine_similarity(self.R.T, dense_output=False)
        return self

    def predict(self, user_id: int, item_id: int) -> float:
        user_row = self.R[user_id].toarray().flatten()
        sim_row  = self.sim[item_id].toarray().flatten()
        # top-K similar items that the user has rated
        rated_mask = user_row > 0
        sim_rated  = sim_row * rated_mask
        top_k_idx  = np.argsort(-sim_rated)[:self.k]
        num   = sim_rated[top_k_idx] @ user_row[top_k_idx]
        denom = np.abs(sim_rated[top_k_idx]).sum() + 1e-9
        return num / denom

    def recommend(self, user_id: int, n: int = 10,
                  seen_items: set = None) -> list[tuple[int, float]]:
        user_row  = self.R[user_id].toarray().flatten()
        seen      = seen_items or set(np.where(user_row > 0)[0])
        all_items = [i for i in range(self.n_items) if i not in seen]
        scores    = [(i, self.predict(user_id, i)) for i in all_items]
        scores.sort(key=lambda x: -x[1])
        return scores[:n]


# ─────────────────────────────────────────────────────────────
# 3. Neural Collaborative Filtering (NCF)
# ─────────────────────────────────────────────────────────────

class NCF(nn.Module):
    """
    Neural Collaborative Filtering:
    GMF branch + MLP branch → concatenate → output.
    """

    def __init__(self, n_users: int, n_items: int,
                 emb_dim: int = 32, hidden: list[int] = None):
        super().__init__()
        hidden = hidden or [64, 32, 16]

        # GMF embeddings
        self.gmf_user = nn.Embedding(n_users, emb_dim)
        self.gmf_item = nn.Embedding(n_items, emb_dim)

        # MLP embeddings
        self.mlp_user = nn.Embedding(n_users, emb_dim)
        self.mlp_item = nn.Embedding(n_items, emb_dim)

        # MLP layers
        mlp_layers: list[nn.Module] = []
        in_size = emb_dim * 2
        for h in hidden:
            mlp_layers += [nn.Linear(in_size, h), nn.ReLU(), nn.Dropout(0.2)]
            in_size = h
        self.mlp = nn.Sequential(*mlp_layers)

        self.output = nn.Linear(emb_dim + hidden[-1], 1)
        self._init_weights()

    def _init_weights(self):
        for emb in [self.gmf_user, self.gmf_item,
                    self.mlp_user, self.mlp_item]:
            nn.init.normal_(emb.weight, std=0.01)

    def forward(self, user_ids: torch.Tensor,
                item_ids: torch.Tensor) -> torch.Tensor:
        gmf = self.gmf_user(user_ids) * self.gmf_item(item_ids)
        mlp_in = torch.cat([self.mlp_user(user_ids),
                            self.mlp_item(item_ids)], dim=-1)
        mlp_out = self.mlp(mlp_in)
        out = torch.cat([gmf, mlp_out], dim=-1)
        return self.output(out).squeeze(-1)


class NCFRecommender:
    """Wrapper to train and serve the NCF model."""

    def __init__(self, emb_dim: int = 32, hidden: list[int] = None,
                 lr: float = 1e-3, n_epochs: int = 10,
                 batch_size: int = 1024, device: str = "cpu"):
        self.emb_dim    = emb_dim
        self.hidden     = hidden or [64, 32, 16]
        self.lr         = lr
        self.n_epochs   = n_epochs
        self.batch_size = batch_size
        self.device     = torch.device(device)

    def fit(self, ratings: np.ndarray, verbose: bool = True):
        users = ratings[:, 0].astype(int)
        items = ratings[:, 1].astype(int)
        rs    = ratings[:, 2].astype(float)

        self.n_users = users.max() + 1
        self.n_items = items.max() + 1

        self.model = NCF(self.n_users, self.n_items,
                         self.emb_dim, self.hidden).to(self.device)
        optimizer  = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        criterion  = nn.MSELoss()

        U = torch.LongTensor(users)
        I = torch.LongTensor(items)
        R = torch.FloatTensor(rs)
        dataset = torch.utils.data.TensorDataset(U, I, R)
        loader  = torch.utils.data.DataLoader(dataset,
                                              batch_size=self.batch_size,
                                              shuffle=True)

        self.model.train()
        for epoch in range(self.n_epochs):
            total_loss = 0.0
            for u_b, i_b, r_b in loader:
                u_b, i_b, r_b = u_b.to(self.device), i_b.to(self.device), r_b.to(self.device)
                optimizer.zero_grad()
                pred = self.model(u_b, i_b)
                loss = criterion(pred, r_b)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
            if verbose and (epoch + 1) % 2 == 0:
                rmse = np.sqrt(total_loss / len(loader))
                print(f"  NCF Epoch {epoch+1:>3}/{self.n_epochs}  RMSE={rmse:.4f}")
        return self

    @torch.no_grad()
    def recommend(self, user_id: int, n: int = 10,
                  seen_items: set = None) -> list[tuple[int, float]]:
        self.model.eval()
        all_items = np.arange(self.n_items)
        if seen_items:
            all_items = all_items[~np.isin(all_items, list(seen_items))]
        u_tensor = torch.LongTensor([user_id] * len(all_items)).to(self.device)
        i_tensor = torch.LongTensor(all_items).to(self.device)
        scores   = self.model(u_tensor, i_tensor).cpu().numpy()
        top_idx  = np.argsort(-scores)[:n]
        return [(int(all_items[i]), float(scores[i])) for i in top_idx]
