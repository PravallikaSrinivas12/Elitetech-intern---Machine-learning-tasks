"""
Evaluation Metrics
==================
Rating prediction : RMSE, MAE
Ranking / top-N   : Precision@K, Recall@K, NDCG@K, Hit Rate@K
"""

import numpy as np
from collections import defaultdict


# ─────────────────────────────────────────────
# Rating Prediction
# ─────────────────────────────────────────────

def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Root Mean Squared Error."""
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Mean Absolute Error."""
    return float(np.mean(np.abs(y_true - y_pred)))


def evaluate_ratings(model, test_data: np.ndarray,
                     model_name: str = "") -> dict:
    """
    Compute RMSE and MAE for a model on test ratings.

    Args:
        model     : Model with a .predict(user_id, item_ids) method.
        test_data : (N, 3) array of [user_id, item_id, rating].
    """
    y_true, y_pred = [], []

    for row in test_data:
        u, i, r = int(row[0]), int(row[1]), float(row[2])
        try:
            pred = float(model.predict(u, np.array([i]))[0])
            y_true.append(r)
            y_pred.append(pred)
        except Exception:
            pass

    y_true = np.array(y_true)
    y_pred = np.clip(np.array(y_pred), 1, 5)   # clamp to rating scale

    result = {"rmse": rmse(y_true, y_pred), "mae": mae(y_true, y_pred)}
    tag = f"[{model_name}] " if model_name else ""
    print(f"  {tag}RMSE={result['rmse']:.4f}  MAE={result['mae']:.4f}")
    return result


# ─────────────────────────────────────────────
# Ranking / Top-N
# ─────────────────────────────────────────────

def precision_at_k(recommended: list, relevant: set, k: int) -> float:
    hits = sum(1 for i in recommended[:k] if i in relevant)
    return hits / k


def recall_at_k(recommended: list, relevant: set, k: int) -> float:
    if not relevant:
        return 0.0
    hits = sum(1 for i in recommended[:k] if i in relevant)
    return hits / len(relevant)


def ndcg_at_k(recommended: list, relevant: set, k: int) -> float:
    """Normalized Discounted Cumulative Gain."""
    dcg = sum(
        1.0 / np.log2(idx + 2)
        for idx, item in enumerate(recommended[:k])
        if item in relevant
    )
    idcg = sum(1.0 / np.log2(idx + 2) for idx in range(min(len(relevant), k)))
    return dcg / idcg if idcg > 0 else 0.0


def hit_rate_at_k(recommended: list, relevant: set, k: int) -> float:
    return float(any(i in relevant for i in recommended[:k]))


def evaluate_ranking(model, test_data: np.ndarray, train_data: np.ndarray,
                     k: int = 10, n_users: int = 200,
                     threshold: float = 4.0,
                     model_name: str = "") -> dict:
    """
    Evaluate top-N ranking metrics averaged over sampled users.

    Args:
        model      : Model with .recommend(user_id, n, seen_items) method.
        test_data  : (N, 3) test ratings.
        train_data : (N, 3) train ratings (to exclude seen items).
        k          : Cutoff for ranking metrics.
        n_users    : Max users to evaluate (for speed).
        threshold  : Min rating considered "relevant".
    """
    # Build per-user relevant sets from test data
    test_relevant: dict[int, set] = defaultdict(set)
    for row in test_data:
        u, i, r = int(row[0]), int(row[1]), float(row[2])
        if r >= threshold:
            test_relevant[u].add(i)

    user_ids = [u for u in test_relevant if test_relevant[u]]
    if n_users < len(user_ids):
        rng = np.random.default_rng(42)
        user_ids = rng.choice(user_ids, n_users, replace=False).tolist()

    p_scores, r_scores, ndcg_scores, hr_scores = [], [], [], []

    for u in user_ids:
        seen = set(train_data[train_data[:, 0].astype(int) == u, 1].astype(int))
        try:
            recs = [item for item, _ in model.recommend(u, n=k, seen_items=seen)]
        except Exception:
            continue
        relevant = test_relevant[u]
        p_scores.append(precision_at_k(recs, relevant, k))
        r_scores.append(recall_at_k(recs, relevant, k))
        ndcg_scores.append(ndcg_at_k(recs, relevant, k))
        hr_scores.append(hit_rate_at_k(recs, relevant, k))

    result = {
        f"precision@{k}" : float(np.mean(p_scores)),
        f"recall@{k}"    : float(np.mean(r_scores)),
        f"ndcg@{k}"      : float(np.mean(ndcg_scores)),
        f"hit_rate@{k}"  : float(np.mean(hr_scores)),
    }
    tag = f"[{model_name}] " if model_name else ""
    for key, val in result.items():
        print(f"  {tag}{key}={val:.4f}")
    return result


def print_metrics_table(results: dict[str, dict]) -> None:
    """Pretty-print a comparison table of metrics across models."""
    all_keys = sorted({k for v in results.values() for k in v})
    col_w    = max(len(m) for m in results) + 2
    hdr_w    = max(len(k) for k in all_keys) + 2

    header = f"{'Metric':<{hdr_w}}" + "".join(f"{m:>{col_w}}" for m in results)
    print("\n" + "=" * len(header))
    print(header)
    print("=" * len(header))
    for key in all_keys:
        row = f"{key:<{hdr_w}}"
        for model_name in results:
            val = results[model_name].get(key, float("nan"))
            row += f"{val:>{col_w}.4f}"
        print(row)
    print("=" * len(header))
