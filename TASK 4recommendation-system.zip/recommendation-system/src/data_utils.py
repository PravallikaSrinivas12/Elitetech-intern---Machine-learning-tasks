"""
Data Utilities
==============
Loads MovieLens-100K (auto-downloaded) or any CSV ratings file.
Provides train/test splitting and negative sampling for NCF.
"""

import os
import urllib.request
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


MOVIELENS_URL  = "https://files.grouplens.org/datasets/movielens/ml-100k.zip"
MOVIELENS_DIR  = Path("data/ml-100k")


def download_movielens(data_dir: str = "data") -> Path:
    """Download and unzip MovieLens-100K if not already present."""
    out_dir = Path(data_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / "ml-100k.zip"

    if not MOVIELENS_DIR.exists():
        print("Downloading MovieLens-100K …")
        urllib.request.urlretrieve(MOVIELENS_URL, zip_path)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(out_dir)
        os.remove(zip_path)
        print("Done.")
    return MOVIELENS_DIR


def load_movielens(data_dir: str = "data") -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Returns:
        ratings  : DataFrame with columns [user_id, item_id, rating, timestamp]
        movies   : DataFrame with columns [item_id, title, genres]
    """
    ml_dir = download_movielens(data_dir)

    ratings = pd.read_csv(
        ml_dir / "u.data",
        sep="\t",
        names=["user_id", "item_id", "rating", "timestamp"],
    )
    # 0-indexed IDs for embedding layers
    ratings["user_id"] -= 1
    ratings["item_id"] -= 1

    movies = pd.read_csv(
        ml_dir / "u.item",
        sep="|", encoding="latin-1",
        usecols=[0, 1],
        names=["item_id", "title"],
    )
    movies["item_id"] -= 1

    return ratings, movies


def load_custom_csv(path: str) -> pd.DataFrame:
    """
    Load a custom ratings CSV.
    Expected columns: user_id, item_id, rating  (0-indexed).
    """
    df = pd.read_csv(path)
    assert {"user_id", "item_id", "rating"}.issubset(df.columns), \
        "CSV must have columns: user_id, item_id, rating"
    return df


def train_test_split_ratings(
    ratings: pd.DataFrame,
    test_size: float = 0.2,
    random_state: int = 42,
) -> tuple[np.ndarray, np.ndarray]:
    """Split ratings into train/test numpy arrays of shape (N, 3)."""
    arr = ratings[["user_id", "item_id", "rating"]].values
    train, test = train_test_split(arr, test_size=test_size,
                                   random_state=random_state)
    return train, test


def get_seen_items(ratings: np.ndarray, user_id: int) -> set:
    """Return set of item IDs rated by a user in the training set."""
    mask = ratings[:, 0].astype(int) == user_id
    return set(ratings[mask, 1].astype(int))


def dataset_stats(ratings: pd.DataFrame) -> dict:
    """Print and return basic dataset statistics."""
    stats = {
        "n_users"  : ratings["user_id"].nunique(),
        "n_items"  : ratings["item_id"].nunique(),
        "n_ratings": len(ratings),
        "density"  : len(ratings) / (ratings["user_id"].nunique()
                                     * ratings["item_id"].nunique()),
        "mean_rating" : ratings["rating"].mean(),
        "rating_range": (ratings["rating"].min(), ratings["rating"].max()),
    }
    print("\n📊 Dataset Statistics")
    print(f"  Users         : {stats['n_users']:,}")
    print(f"  Items         : {stats['n_items']:,}")
    print(f"  Ratings       : {stats['n_ratings']:,}")
    print(f"  Density       : {stats['density']:.4%}")
    print(f"  Mean rating   : {stats['mean_rating']:.2f}")
    print(f"  Rating range  : {stats['rating_range']}")
    return stats
