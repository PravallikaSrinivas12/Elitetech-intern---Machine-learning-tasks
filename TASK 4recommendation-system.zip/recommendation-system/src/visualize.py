"""
Visualization Utilities
=======================
Generates publication-quality plots saved to results/.
"""

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


SAVE_DIR = Path("results")
SAVE_DIR.mkdir(parents=True, exist_ok=True)


def plot_rating_distribution(ratings, save: bool = True):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    # Rating frequency
    ratings["rating"].value_counts().sort_index().plot(
        kind="bar", ax=axes[0], color="#4C72B0", edgecolor="white")
    axes[0].set(title="Rating Distribution", xlabel="Rating", ylabel="Count")

    # Ratings per user
    user_counts = ratings.groupby("user_id")["rating"].count()
    axes[1].hist(user_counts, bins=40, color="#55A868", edgecolor="white")
    axes[1].set(title="Ratings per User", xlabel="# Ratings", ylabel="# Users")

    # Ratings per item
    item_counts = ratings.groupby("item_id")["rating"].count()
    axes[2].hist(item_counts, bins=40, color="#C44E52", edgecolor="white")
    axes[2].set(title="Ratings per Item", xlabel="# Ratings", ylabel="# Items")

    fig.tight_layout()
    if save:
        path = SAVE_DIR / "rating_distribution.png"
        fig.savefig(path, dpi=150); print(f"Saved → {path}")
    plt.close(fig)


def plot_model_comparison(results: dict[str, dict], save: bool = True):
    """Bar chart comparison of all metrics across models."""
    models  = list(results.keys())
    metrics = sorted({k for v in results.values() for k in v})
    x       = np.arange(len(metrics))
    width   = 0.8 / len(models)
    colors  = ["#4C72B0", "#55A868", "#C44E52", "#8172B2"]

    fig, ax = plt.subplots(figsize=(14, 5))
    for idx, (model, color) in enumerate(zip(models, colors)):
        vals = [results[model].get(m, 0) for m in metrics]
        bars = ax.bar(x + idx * width, vals, width, label=model,
                      color=color, edgecolor="white", alpha=0.9)
        for bar, val in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.002,
                    f"{val:.3f}", ha="center", va="bottom", fontsize=7)

    ax.set(xticks=x + width * (len(models) - 1) / 2,
           xticklabels=metrics, title="Model Comparison",
           ylabel="Score")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    if save:
        path = SAVE_DIR / "model_comparison.png"
        fig.savefig(path, dpi=150); print(f"Saved → {path}")
    plt.close(fig)


def plot_top_recommendations(recs: list[tuple[int, float]],
                             movie_titles: dict[int, str],
                             user_id: int,
                             model_name: str = "SVD",
                             save: bool = True):
    """Horizontal bar chart of top-N recommendations for one user."""
    items  = [movie_titles.get(i, f"Item {i}") for i, _ in recs]
    scores = [s for _, s in recs]

    fig, ax = plt.subplots(figsize=(10, 5))
    bars = ax.barh(items[::-1], scores[::-1], color="#4C72B0", edgecolor="white")
    ax.bar_label(bars, fmt="%.2f", padding=3, fontsize=8)
    ax.set(title=f"Top-{len(recs)} Recommendations for User {user_id} ({model_name})",
           xlabel="Predicted Score")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    if save:
        path = SAVE_DIR / f"recommendations_user{user_id}.png"
        fig.savefig(path, dpi=150); print(f"Saved → {path}")
    plt.close(fig)


def plot_precision_recall_curve(model, test_data, train_data,
                                ks: list[int] = None,
                                model_name: str = "Model",
                                threshold: float = 4.0,
                                save: bool = True):
    """Precision vs Recall curve at different K values."""
    from src.metrics import evaluate_ranking
    if ks is None:
        ks = [5, 10, 15, 20, 30]

    precisions, recalls = [], []
    for k in ks:
        res = evaluate_ranking(model, test_data, train_data,
                               k=k, n_users=100, threshold=threshold)
        precisions.append(res.get(f"precision@{k}", 0))
        recalls.append(res.get(f"recall@{k}", 0))

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(recalls, precisions, "o-", color="#4C72B0", linewidth=2)
    for p, r, k in zip(precisions, recalls, ks):
        ax.annotate(f"K={k}", (r, p), textcoords="offset points",
                    xytext=(5, 5), fontsize=8)
    ax.set(title=f"Precision-Recall Curve — {model_name}",
           xlabel="Recall", ylabel="Precision")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    if save:
        path = SAVE_DIR / f"pr_curve_{model_name.lower()}.png"
        fig.savefig(path, dpi=150); print(f"Saved → {path}")
    plt.close(fig)
