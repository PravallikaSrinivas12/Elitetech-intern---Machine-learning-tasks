"""
Main Pipeline
=============
Trains SVD, ItemKNN, and NCF on MovieLens-100K,
evaluates all models, and saves plots to results/.

Usage:
    python src/main.py
    python src/main.py --models svd knn   # train only specific models
    python src/main.py --k 20             # evaluate at K=20
"""

import argparse
import json
from pathlib import Path

import numpy as np

from data_utils import load_movielens, train_test_split_ratings, dataset_stats, get_seen_items
from models import SVDRecommender, ItemKNNRecommender, NCFRecommender
from metrics import evaluate_ratings, evaluate_ranking, print_metrics_table
from visualize import (plot_rating_distribution, plot_model_comparison,
                       plot_top_recommendations)


def parse_args():
    p = argparse.ArgumentParser(description="Train & evaluate recommendation models")
    p.add_argument("--models", nargs="+", default=["svd", "knn", "ncf"],
                   choices=["svd", "knn", "ncf"])
    p.add_argument("--k",          type=int, default=10)
    p.add_argument("--svd-epochs", type=int, default=20)
    p.add_argument("--ncf-epochs", type=int, default=10)
    p.add_argument("--data-dir",   type=str, default="data")
    p.add_argument("--save-dir",   type=str, default="results")
    p.add_argument("--user-id",    type=int, default=0,
                   help="User ID to showcase recommendations for")
    return p.parse_args()


def main():
    args = parse_args()
    Path(args.save_dir).mkdir(parents=True, exist_ok=True)

    # ── Load data ─────────────────────────────
    print("\n📥 Loading MovieLens-100K …")
    ratings, movies = load_movielens(args.data_dir)
    stats = dataset_stats(ratings)
    movie_titles = dict(zip(movies["item_id"], movies["title"]))

    train_data, test_data = train_test_split_ratings(ratings)
    print(f"\n  Train: {len(train_data):,} | Test: {len(test_data):,}")

    # ── EDA plot ──────────────────────────────
    plot_rating_distribution(ratings)

    # ── Train models ──────────────────────────
    trained = {}

    if "svd" in args.models:
        print("\n🔧 Training SVD …")
        svd = SVDRecommender(n_factors=50, n_epochs=args.svd_epochs)
        svd.fit(train_data)
        trained["SVD"] = svd

    if "knn" in args.models:
        print("\n🔧 Training ItemKNN …")
        knn = ItemKNNRecommender(k=20)
        knn.fit(train_data)
        trained["ItemKNN"] = knn

    if "ncf" in args.models:
        print("\n🔧 Training NCF …")
        ncf = NCFRecommender(emb_dim=32, n_epochs=args.ncf_epochs)
        ncf.fit(train_data)
        trained["NCF"] = ncf

    # ── Evaluate ──────────────────────────────
    all_results: dict[str, dict] = {}

    print("\n📏 Rating Prediction Metrics:")
    for name, model in trained.items():
        if hasattr(model, "predict"):
            r = evaluate_ratings(model, test_data, model_name=name)
            all_results.setdefault(name, {}).update(r)

    print(f"\n📏 Ranking Metrics @ K={args.k}:")
    for name, model in trained.items():
        r = evaluate_ranking(model, test_data, train_data,
                             k=args.k, model_name=name)
        all_results.setdefault(name, {}).update(r)

    print_metrics_table(all_results)

    # ── Save metrics JSON ─────────────────────
    json_path = Path(args.save_dir) / "metrics.json"
    with open(json_path, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\n✅ Metrics saved → {json_path}")

    # ── Model comparison plot ─────────────────
    plot_model_comparison(all_results)

    # ── Sample recommendations ────────────────
    uid = args.user_id
    seen = get_seen_items(train_data, uid)
    print(f"\n🎬 Top-{args.k} recommendations for User {uid}:")
    for name, model in trained.items():
        recs = model.recommend(uid, n=args.k, seen_items=seen)
        print(f"\n  [{name}]")
        for rank, (item_id, score) in enumerate(recs, 1):
            title = movie_titles.get(item_id, f"Item {item_id}")
            print(f"    {rank:>2}. {title:<45} ({score:.2f})")

    # Save recommendation chart for first model
    first_name, first_model = next(iter(trained.items()))
    recs = first_model.recommend(uid, n=10, seen_items=seen)
    plot_top_recommendations(recs, movie_titles, uid, model_name=first_name)

    print("\n✅ All done! Check the results/ folder for plots.")


if __name__ == "__main__":
    main()
