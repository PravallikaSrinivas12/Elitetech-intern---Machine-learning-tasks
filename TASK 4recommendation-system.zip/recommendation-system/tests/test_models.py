"""
Unit Tests — pytest tests/
"""
import sys
sys.path.insert(0, 'src')

import numpy as np
import pytest
from src.models import SVDRecommender, ItemKNNRecommender
from src.metrics import rmse, mae, precision_at_k, recall_at_k, ndcg_at_k


# ── Fixtures ──────────────────────────────────

@pytest.fixture
def small_ratings():
    """50 synthetic ratings: 10 users, 20 items, ratings 1-5."""
    rng = np.random.default_rng(0)
    users = rng.integers(0, 10, 50)
    items = rng.integers(0, 20, 50)
    rates = rng.integers(1, 6,  50).astype(float)
    return np.column_stack([users, items, rates])


@pytest.fixture
def svd_model(small_ratings):
    m = SVDRecommender(n_factors=5, n_epochs=3)
    m.fit(small_ratings, verbose=False)
    return m


@pytest.fixture
def knn_model(small_ratings):
    m = ItemKNNRecommender(k=5)
    m.fit(small_ratings)
    return m


# ── SVD tests ─────────────────────────────────

def test_svd_predict_shape(svd_model):
    scores = svd_model.predict(0, np.array([0, 1, 2]))
    assert len(scores) == 3

def test_svd_recommend_length(svd_model):
    recs = svd_model.recommend(0, n=5)
    assert len(recs) == 5

def test_svd_recommend_no_seen(svd_model):
    seen = {0, 1, 2}
    recs = svd_model.recommend(0, n=5, seen_items=seen)
    assert all(item not in seen for item, _ in recs)


# ── KNN tests ─────────────────────────────────

def test_knn_recommend_length(knn_model):
    recs = knn_model.recommend(0, n=5)
    assert len(recs) <= 5   # may be less if not enough unseen items

def test_knn_predict_range(knn_model):
    score = knn_model.predict(0, 0)
    assert isinstance(score, float)


# ── Metric tests ──────────────────────────────

def test_rmse_perfect():
    y = np.array([3.0, 4.0, 5.0])
    assert rmse(y, y) == pytest.approx(0.0)

def test_mae_perfect():
    y = np.array([1.0, 2.0, 3.0])
    assert mae(y, y) == pytest.approx(0.0)

def test_precision_at_k_all_relevant():
    recs = [1, 2, 3, 4, 5]
    rel  = {1, 2, 3, 4, 5}
    assert precision_at_k(recs, rel, k=5) == pytest.approx(1.0)

def test_recall_at_k_none():
    assert recall_at_k([1, 2], set(), k=2) == pytest.approx(0.0)

def test_ndcg_at_k_perfect():
    recs = [1, 2, 3]
    rel  = {1, 2, 3}
    assert ndcg_at_k(recs, rel, k=3) == pytest.approx(1.0)
