"""
Unit Tests
==========
Run with:  pytest tests/
"""

import pytest
import torch
from src.model import CNN, count_parameters


@pytest.fixture
def model():
    return CNN(num_classes=10)


def test_output_shape(model):
    x = torch.randn(8, 3, 32, 32)
    out = model(x)
    assert out.shape == (8, 10), f"Expected (8, 10), got {out.shape}"


def test_parameter_count(model):
    params = count_parameters(model)
    assert params > 0, "Model has no trainable parameters"
    print(f"\nTrainable parameters: {params:,}")


def test_forward_no_nan(model):
    x = torch.randn(4, 3, 32, 32)
    out = model(x)
    assert not torch.isnan(out).any(), "NaN values detected in model output"


def test_different_num_classes():
    for n in [2, 5, 100]:
        m = CNN(num_classes=n)
        out = m(torch.randn(2, 3, 32, 32))
        assert out.shape[1] == n


def test_batch_size_one(model):
    x = torch.randn(1, 3, 32, 32)
    out = model(x)
    assert out.shape == (1, 10)


def test_model_in_eval_mode(model):
    model.eval()
    with torch.no_grad():
        x = torch.randn(4, 3, 32, 32)
        out1 = model(x)
        out2 = model(x)
    assert torch.allclose(out1, out2), "Outputs differ in eval mode (dropout not disabled?)"
