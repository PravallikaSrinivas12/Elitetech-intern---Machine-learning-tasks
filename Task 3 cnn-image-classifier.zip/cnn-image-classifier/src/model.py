"""
CNN Model Architecture for Image Classification
================================================
A flexible Convolutional Neural Network built with PyTorch.
Designed for CIFAR-10 but adaptable to other datasets.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvBlock(nn.Module):
    """Reusable Conv → BN → ReLU block with optional MaxPool."""

    def __init__(self, in_channels, out_channels, pool=False):
        super().__init__()
        layers = [
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        ]
        if pool:
            layers.append(nn.MaxPool2d(2))
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        return self.block(x)


class CNN(nn.Module):
    """
    CNN for image classification.

    Architecture:
        Block 1: Conv(3→64)  + Conv(64→128)  + Pool → 16×16
        Block 2: Conv(128→256) + Conv(256→256) + Pool → 8×8
        Block 3: Conv(256→512) + Conv(512→512) + Pool → 4×4
        Classifier: GAP → FC(512→256) → Dropout → FC(256→num_classes)

    Args:
        num_classes (int): Number of output classes. Default: 10.
        dropout (float): Dropout probability before final FC. Default: 0.5.
    """

    def __init__(self, num_classes: int = 10, dropout: float = 0.5):
        super().__init__()

        self.features = nn.Sequential(
            # Block 1
            ConvBlock(3, 64),
            ConvBlock(64, 128, pool=True),
            # Block 2
            ConvBlock(128, 256),
            ConvBlock(256, 256, pool=True),
            # Block 3
            ConvBlock(256, 512),
            ConvBlock(512, 512, pool=True),
        )

        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),         # Global Average Pooling
            nn.Flatten(),
            nn.Linear(512, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.classifier(x)
        return x


def count_parameters(model: nn.Module) -> int:
    """Return the number of trainable parameters."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


if __name__ == "__main__":
    model = CNN(num_classes=10)
    dummy = torch.randn(4, 3, 32, 32)
    out = model(dummy)
    print(f"Output shape : {out.shape}")
    print(f"Parameters   : {count_parameters(model):,}")
