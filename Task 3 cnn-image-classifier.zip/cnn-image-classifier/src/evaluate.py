"""
Evaluation Script
=================
Loads a saved checkpoint and reports:
  • Overall test accuracy
  • Per-class accuracy
  • Confusion matrix (saved as PNG)
  • Classification report (precision / recall / F1)

Usage:
    python src/evaluate.py --checkpoint results/best_model.pth
"""

import argparse
from pathlib import Path

import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix

from dataset import get_cifar10_loaders, CLASSES
from model import CNN


def parse_args():
    p = argparse.ArgumentParser(description="Evaluate trained CNN")
    p.add_argument("--checkpoint", type=str, default="results/best_model.pth")
    p.add_argument("--data-dir",   type=str, default="./data")
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--save-dir",   type=str, default="./results")
    return p.parse_args()


@torch.no_grad()
def get_predictions(model, loader, device):
    model.eval()
    all_preds, all_labels = [], []
    for images, labels in loader:
        images = images.to(device)
        outputs = model(images)
        preds = outputs.argmax(dim=1).cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(labels.numpy())
    return np.array(all_labels), np.array(all_preds)


def plot_confusion_matrix(cm, classes, save_path):
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(cm, interpolation="nearest", cmap=plt.cm.Blues)
    fig.colorbar(im)
    tick_marks = np.arange(len(classes))
    ax.set(
        xticks=tick_marks, xticklabels=classes,
        yticks=tick_marks, yticklabels=classes,
        ylabel="True label", xlabel="Predicted label",
        title="Confusion Matrix",
    )
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")

    thresh = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], "d"),
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black",
                    fontsize=8)
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    print(f"Confusion matrix saved → {save_path}")
    plt.close(fig)


def plot_training_history(history_path, save_dir):
    import json
    if not Path(history_path).exists():
        return
    with open(history_path) as f:
        h = json.load(f)

    epochs = range(1, len(h["train_loss"]) + 1)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

    ax1.plot(epochs, h["train_loss"], label="Train")
    ax1.plot(epochs, h["val_loss"],   label="Val")
    ax1.set(title="Loss", xlabel="Epoch", ylabel="Loss")
    ax1.legend(); ax1.grid(True, alpha=0.3)

    ax2.plot(epochs, h["train_acc"], label="Train")
    ax2.plot(epochs, h["val_acc"],   label="Val")
    ax2.set(title="Accuracy", xlabel="Epoch", ylabel="Accuracy (%)")
    ax2.legend(); ax2.grid(True, alpha=0.3)

    fig.tight_layout()
    out = Path(save_dir) / "training_curves.png"
    fig.savefig(out, dpi=150)
    print(f"Training curves saved  → {out}")
    plt.close(fig)


def main():
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    # ── Load checkpoint ────────────────────────
    ckpt = torch.load(args.checkpoint, map_location=device)
    model = CNN(num_classes=10).to(device)
    model.load_state_dict(ckpt["model_state"])
    print(f"Loaded checkpoint from epoch {ckpt.get('epoch', '?')} "
          f"(val_acc={ckpt.get('val_acc', 0):.2f}%)")

    # ── Test data ─────────────────────────────
    _, _, test_loader = get_cifar10_loaders(
        data_dir=args.data_dir, batch_size=args.batch_size
    )

    # ── Predictions ───────────────────────────
    y_true, y_pred = get_predictions(model, test_loader, device)
    overall_acc = 100.0 * (y_true == y_pred).mean()

    print(f"\n{'='*50}")
    print(f"  Test Accuracy : {overall_acc:.2f}%")
    print(f"{'='*50}\n")

    # ── Per-class accuracy ────────────────────
    print("Per-class accuracy:")
    for i, cls in enumerate(CLASSES):
        mask = y_true == i
        cls_acc = 100.0 * (y_pred[mask] == i).mean()
        bar = "█" * int(cls_acc / 5)
        print(f"  {cls:<12} {cls_acc:5.1f}%  {bar}")

    # ── Classification report ─────────────────
    print("\nClassification Report:")
    print(classification_report(y_true, y_pred, target_names=CLASSES, digits=3))

    # ── Confusion matrix ──────────────────────
    cm = confusion_matrix(y_true, y_pred)
    plot_confusion_matrix(cm, CLASSES, save_dir / "confusion_matrix.png")

    # ── Training curves ───────────────────────
    plot_training_history(save_dir / "history.json", save_dir)


if __name__ == "__main__":
    main()
