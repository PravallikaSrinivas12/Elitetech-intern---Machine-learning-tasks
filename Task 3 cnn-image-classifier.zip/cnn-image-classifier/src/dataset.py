"""
Dataset Utilities
=================
Handles downloading, augmenting, and loading CIFAR-10.
Swap `get_cifar10_loaders` with your own loader to use a custom dataset.
"""

import torch
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, transforms

CIFAR10_MEAN = (0.4914, 0.4822, 0.4465)
CIFAR10_STD  = (0.2023, 0.1994, 0.2010)

CLASSES = (
    "airplane", "automobile", "bird", "cat", "deer",
    "dog", "frog", "horse", "ship", "truck",
)


def get_train_transforms() -> transforms.Compose:
    return transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
        transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
    ])


def get_test_transforms() -> transforms.Compose:
    return transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
    ])


def get_cifar10_loaders(
    data_dir: str = "./data",
    batch_size: int = 128,
    val_split: float = 0.1,
    num_workers: int = 2,
) -> tuple[DataLoader, DataLoader, DataLoader]:
    """
    Download CIFAR-10 and return (train_loader, val_loader, test_loader).

    Args:
        data_dir    : Where to cache the dataset.
        batch_size  : Mini-batch size.
        val_split   : Fraction of training data used for validation.
        num_workers : DataLoader worker processes.

    Returns:
        Tuple of (train_loader, val_loader, test_loader).
    """
    full_train = datasets.CIFAR10(
        root=data_dir, train=True, download=True,
        transform=get_train_transforms(),
    )
    test_ds = datasets.CIFAR10(
        root=data_dir, train=False, download=True,
        transform=get_test_transforms(),
    )

    n_val = int(len(full_train) * val_split)
    n_train = len(full_train) - n_val
    train_ds, val_ds = random_split(
        full_train, [n_train, n_val],
        generator=torch.Generator().manual_seed(42),
    )
    # Validation should use test transforms (no augmentation)
    val_ds.dataset.transform = get_test_transforms()

    loader_kwargs = dict(batch_size=batch_size, num_workers=num_workers, pin_memory=True)
    train_loader = DataLoader(train_ds, shuffle=True,  **loader_kwargs)
    val_loader   = DataLoader(val_ds,   shuffle=False, **loader_kwargs)
    test_loader  = DataLoader(test_ds,  shuffle=False, **loader_kwargs)

    return train_loader, val_loader, test_loader
