"""
Training Script
===============
Trains the CNN on CIFAR-10, saves the best checkpoint,
and writes a training-history JSON for later plotting.

Usage:
    python src/train.py                        # defaults
    python src/train.py --epochs 50 --lr 0.01
"""

import argparse
import json
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR

from dataset import get_cifar10_loaders
from model import CNN, count_parameters


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def get_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    total_loss = correct = total = 0

    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        correct += predicted.eq(labels).sum().item()
        total   += images.size(0)

    return total_loss / total, 100.0 * correct / total


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()
    total_loss = correct = total = 0

    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        loss = criterion(outputs, labels)

        total_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        correct += predicted.eq(labels).sum().item()
        total   += images.size(0)

    return total_loss / total, 100.0 * correct / total


# ──────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="Train CNN on CIFAR-10")
    p.add_argument("--epochs",      type=int,   default=30)
    p.add_argument("--lr",          type=float, default=0.001)
    p.add_argument("--batch-size",  type=int,   default=128)
    p.add_argument("--weight-decay",type=float, default=1e-4)
    p.add_argument("--dropout",     type=float, default=0.5)
    p.add_argument("--data-dir",    type=str,   default="./data")
    p.add_argument("--save-dir",    type=str,   default="./results")
    return p.parse_args()


def main():
    args = parse_args()
    device = get_device()
    print(f"Device : {device}")

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    # ── Data ──────────────────────────────────
    train_loader, val_loader, _ = get_cifar10_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
    )

    # ── Model ─────────────────────────────────
    model = CNN(num_classes=10, dropout=args.dropout).to(device)
    print(f"Parameters : {count_parameters(model):,}")

    criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
    optimizer = optim.AdamW(
        model.parameters(), lr=args.lr, weight_decay=args.weight_decay
    )
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs)

    # ── Training loop ─────────────────────────
    history = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}
    best_val_acc = 0.0

    print(f"\n{'Epoch':>5} | {'Train Loss':>10} | {'Train Acc':>9} | "
          f"{'Val Loss':>8} | {'Val Acc':>7} | {'LR':>8} | {'Time':>6}")
    print("-" * 70)

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        tr_loss, tr_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        vl_loss, vl_acc = evaluate(model, val_loader, criterion, device)
        scheduler.step()
        elapsed = time.time() - t0

        history["train_loss"].append(tr_loss)
        history["train_acc"].append(tr_acc)
        history["val_loss"].append(vl_loss)
        history["val_acc"].append(vl_acc)

        lr = scheduler.get_last_lr()[0]
        print(f"{epoch:>5} | {tr_loss:>10.4f} | {tr_acc:>8.2f}% | "
              f"{vl_loss:>8.4f} | {vl_acc:>6.2f}% | {lr:>8.6f} | {elapsed:>5.1f}s")

        if vl_acc > best_val_acc:
            best_val_acc = vl_acc
            torch.save(
                {"epoch": epoch, "model_state": model.state_dict(),
                 "val_acc": vl_acc, "args": vars(args)},
                save_dir / "best_model.pth",
            )
            print(f"  ✓ Saved best model  (val_acc={vl_acc:.2f}%)")

    with open(save_dir / "history.json", "w") as f:
        json.dump(history, f, indent=2)

    print(f"\nTraining complete. Best val acc: {best_val_acc:.2f}%")
    print(f"Checkpoint saved to : {save_dir / 'best_model.pth'}")


if __name__ == "__main__":
    main()
