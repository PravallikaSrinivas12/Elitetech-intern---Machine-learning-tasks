"""
Inference Script
================
Run prediction on a single image or folder of images.

Usage:
    python src/predict.py --image path/to/image.jpg
    python src/predict.py --folder path/to/folder/
"""

import argparse
from pathlib import Path

import torch
import torch.nn.functional as F
from PIL import Image
from torchvision import transforms

from dataset import CIFAR10_MEAN, CIFAR10_STD, CLASSES
from model import CNN

IMG_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def get_transform():
    return transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.ToTensor(),
        transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
    ])


def load_model(checkpoint_path: str, device: torch.device) -> CNN:
    ckpt = torch.load(checkpoint_path, map_location=device)
    model = CNN(num_classes=10).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    return model


@torch.no_grad()
def predict_image(model, image_path: str, transform, device) -> dict:
    img = Image.open(image_path).convert("RGB")
    tensor = transform(img).unsqueeze(0).to(device)
    logits = model(tensor)
    probs = F.softmax(logits, dim=1).squeeze(0).cpu().numpy()
    top5_idx = probs.argsort()[::-1][:5]
    return {
        "file": Path(image_path).name,
        "prediction": CLASSES[top5_idx[0]],
        "confidence": float(probs[top5_idx[0]]) * 100,
        "top5": [(CLASSES[i], float(probs[i]) * 100) for i in top5_idx],
    }


def parse_args():
    p = argparse.ArgumentParser(description="Predict image class with trained CNN")
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument("--image",  type=str, help="Path to a single image")
    group.add_argument("--folder", type=str, help="Path to a folder of images")
    p.add_argument("--checkpoint", type=str, default="results/best_model.pth")
    return p.parse_args()


def main():
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = load_model(args.checkpoint, device)
    transform = get_transform()

    images = (
        [args.image]
        if args.image
        else [
            str(p) for p in Path(args.folder).iterdir()
            if p.suffix.lower() in IMG_EXTENSIONS
        ]
    )

    if not images:
        print("No images found.")
        return

    for img_path in images:
        result = predict_image(model, img_path, transform, device)
        print(f"\n📷 {result['file']}")
        print(f"   Prediction : {result['prediction']}  ({result['confidence']:.1f}%)")
        print("   Top-5:")
        for cls, conf in result["top5"]:
            bar = "▪" * int(conf / 5)
            print(f"     {cls:<12} {conf:5.1f}%  {bar}")


if __name__ == "__main__":
    main()
