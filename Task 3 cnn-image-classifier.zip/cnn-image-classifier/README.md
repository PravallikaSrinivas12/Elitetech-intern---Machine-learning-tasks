# 🧠 CNN Image Classifier

A clean, production-style **Convolutional Neural Network** built with **PyTorch** for multi-class image classification on the **CIFAR-10** dataset.

> Achieves **~88–90% test accuracy** in 30 epochs on a single GPU.

---

## 📁 Project Structure

```
cnn-image-classifier/
├── src/
│   ├── model.py       # CNN architecture (ConvBlock + classifier head)
│   ├── dataset.py     # CIFAR-10 loading + augmentation pipeline
│   ├── train.py       # Training loop with cosine LR schedule
│   ├── evaluate.py    # Test metrics, confusion matrix, training curves
│   └── predict.py     # Inference on new images
├── tests/
│   └── test_model.py  # Pytest unit tests
├── results/           # Saved checkpoints + plots (auto-created)
├── requirements.txt
├── .gitignore
└── README.md
```

---

## 🏗️ Model Architecture

```
Input (3×32×32)
   │
   ├─ ConvBlock(3→64)  + ConvBlock(64→128)  + MaxPool  →  128×16×16
   ├─ ConvBlock(128→256) + ConvBlock(256→256) + MaxPool →  256×8×8
   ├─ ConvBlock(256→512) + ConvBlock(512→512) + MaxPool →  512×4×4
   │
   ├─ Global Average Pooling  →  512
   ├─ Linear(512→256) + ReLU + Dropout(0.5)
   └─ Linear(256→10)
```

Each **ConvBlock** = Conv2d → BatchNorm → ReLU (+ optional MaxPool).  
Total trainable parameters: **~4.7 M**

---

## 🚀 Quick Start

### 1. Clone & install

```bash
git clone https://github.com/<your-username>/cnn-image-classifier.git
cd cnn-image-classifier
pip install -r requirements.txt
```

### 2. Train

```bash
python src/train.py                        # 30 epochs, defaults
python src/train.py --epochs 50 --lr 0.001 # custom settings
```

Training flags:

| Flag | Default | Description |
|------|---------|-------------|
| `--epochs` | 30 | Number of training epochs |
| `--lr` | 0.001 | Initial learning rate |
| `--batch-size` | 128 | Mini-batch size |
| `--weight-decay` | 1e-4 | AdamW weight decay |
| `--dropout` | 0.5 | Dropout probability |
| `--data-dir` | ./data | Dataset cache directory |
| `--save-dir` | ./results | Checkpoint output directory |

### 3. Evaluate on test set

```bash
python src/evaluate.py --checkpoint results/best_model.pth
```

Outputs:
- Overall test accuracy
- Per-class accuracy table
- `results/confusion_matrix.png`
- `results/training_curves.png`
- Full classification report (precision / recall / F1)

### 4. Predict on your own images

```bash
# Single image
python src/predict.py --image path/to/cat.jpg

# Entire folder
python src/predict.py --folder path/to/my_images/
```

### 5. Run unit tests

```bash
pytest tests/ -v
```

---

## 📊 Training Details

| Setting | Value |
|---------|-------|
| Dataset | CIFAR-10 (50k train / 10k test) |
| Optimizer | AdamW |
| LR schedule | Cosine Annealing |
| Loss | CrossEntropyLoss + Label Smoothing (0.1) |
| Augmentation | RandomCrop, HorizontalFlip, ColorJitter |
| Validation split | 10% of training set |

---

## 📈 Expected Results

| Metric | Value |
|--------|-------|
| Test Accuracy | ~88–90% |
| Best Val Accuracy | ~89–91% |

---

## 🔧 Adapting to Your Own Dataset

1. **Replace the loader** — edit `src/dataset.py` and swap `get_cifar10_loaders` with a function that returns `(train_loader, val_loader, test_loader)` for your data.
2. **Adjust `num_classes`** — pass `--num-classes N` or change the default in `train.py`.
3. **Resize transforms** — if your images aren't 32×32, update `transforms.Resize(...)` in `dataset.py` and `predict.py`.

---

## 📦 Dependencies

- `torch` ≥ 2.1
- `torchvision` ≥ 0.16
- `numpy`, `matplotlib`, `scikit-learn`, `Pillow`

---

## 📄 License

MIT — free to use, modify, and distribute.
