# 🌳 Decision Tree Implementation — Scikit-Learn

> **Build, Visualize & Analyze a Decision Tree Classifier** on the Iris dataset using Python and Scikit-Learn.

---

## 📌 Project Overview

This project demonstrates a complete **Decision Tree Classification** pipeline — from raw data exploration to model evaluation and visualization. It is structured as a well-documented Jupyter Notebook suitable for learning, academic submission, or portfolio use.

| Item | Details |
|------|---------|
| **Dataset** | Iris Flower Dataset (150 samples, 4 features, 3 classes) |
| **Algorithm** | Decision Tree Classifier (Scikit-Learn) |
| **Task** | Multi-class Classification |
| **Language** | Python 3.8+ |
| **Test Accuracy** | ~97.37% |
| **CV Accuracy** | ~95%+ (10-fold) |

---

## 📁 Project Structure

```
decision-tree-implementation/
│
├── Decision_Tree_Implementation.ipynb   ← Main Jupyter Notebook
├── requirements.txt                     ← Python dependencies
├── README.md                            ← Project documentation
│
└── images/                              ← All generated visualizations
    ├── 01_feature_distributions.png
    ├── 02_pairplot.png
    ├── 03_correlation_heatmap.png
    ├── 04_decision_tree.png
    ├── 05_confusion_matrix.png
    ├── 06_feature_importance.png
    ├── 07_depth_analysis.png
    ├── 08_decision_boundary.png
    └── 09_cross_validation.png
```

---

## 🔬 Notebook Sections

| # | Section | Description |
|---|---------|-------------|
| 1 | Import Libraries | All required packages |
| 2 | Load & Explore Dataset | Shape, samples, class distribution |
| 3 | Exploratory Data Analysis | Histograms, pairplot, correlation heatmap |
| 4 | Train-Test Split | 75/25 stratified split |
| 5 | Train Decision Tree | Gini criterion, depth=4 |
| 6 | Tree Visualization | Full graphical tree + text rules |
| 7 | Model Evaluation | Accuracy, classification report |
| 8 | Confusion Matrix | Heatmap visualization |
| 9 | Feature Importance | Bar chart of Gini importances |
| 10 | Hyperparameter Tuning | Depth analysis — overfitting curve |
| 11 | Decision Boundary | 2D boundary on top 2 features |
| 12 | Cross-Validation | 10-fold CV with bar chart |
| 13 | Summary | Key findings and results |

---

## 📊 Visualizations

### Decision Tree
![Decision Tree](images/04_decision_tree.png)

### Feature Distributions
![Feature Distributions](images/01_feature_distributions.png)

### Confusion Matrix
![Confusion Matrix](images/05_confusion_matrix.png)

### Feature Importance
![Feature Importance](images/06_feature_importance.png)

### Depth Analysis (Overfitting Curve)
![Depth Analysis](images/07_depth_analysis.png)

### Decision Boundary
![Decision Boundary](images/08_decision_boundary.png)

### Cross-Validation Results
![Cross Validation](images/09_cross_validation.png)

---

## ⚙️ Setup & Run

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/decision-tree-implementation.git
cd decision-tree-implementation
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Launch the Notebook
```bash
jupyter notebook Decision_Tree_Implementation.ipynb
```

> Or open it directly in **VS Code**, **JupyterLab**, or **Google Colab**.

---

## 📦 Requirements

```
numpy
pandas
matplotlib
seaborn
scikit-learn
jupyter
nbformat
```

Install all with:
```bash
pip install -r requirements.txt
```

---

## 🔑 Key Findings

- **Petal Length** and **Petal Width** are the most discriminative features (highest Gini importance).
- **Setosa** is perfectly separable from the other two classes using petal dimensions alone.
- **Versicolor** and **Virginica** have a slight overlap, making them the harder boundary to learn.
- A tree depth of **4** provides the best balance between accuracy and generalization.
- **10-fold cross-validation** confirms the model generalizes well, with mean accuracy ≥ 95%.

---

## 📈 Model Performance

| Metric | Score |
|--------|-------|
| Training Accuracy | 98.21% |
| Test Accuracy | 97.37% |
| 10-Fold CV Mean | ~95%+ |
| Precision (macro avg) | 0.97 |
| Recall (macro avg) | 0.97 |
| F1-Score (macro avg) | 0.97 |

---

## 🛠 Technologies Used

- **Python 3.8+**
- **Scikit-Learn** — Model training, evaluation, cross-validation
- **Matplotlib** — Tree visualization, plots
- **Seaborn** — Statistical visualizations
- **Pandas / NumPy** — Data manipulation
- **Jupyter Notebook** — Interactive environment

---

## 📚 References

- [Scikit-Learn Decision Tree Docs](https://scikit-learn.org/stable/modules/tree.html)
- [Iris Dataset — UCI ML Repository](https://archive.ics.uci.edu/ml/datasets/iris)
- Breiman, L. et al. (1984). *Classification and Regression Trees*. Wadsworth.

---

## 📄 License

This project is licensed under the **MIT License** — feel free to use and adapt.

---

*Made with 🌳 and Python*
