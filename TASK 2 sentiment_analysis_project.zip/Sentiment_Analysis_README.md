# 💬 Sentiment Analysis with NLP

> **Customer Review Classification** using **TF-IDF Vectorization** and **Logistic Regression** — a complete NLP pipeline from raw text to actionable sentiment predictions.

---

## 📌 Project Overview

This project builds an end-to-end **Natural Language Processing (NLP)** pipeline to classify customer reviews as **Positive** or **Negative**. It covers every stage: data exploration, text preprocessing, feature extraction with TF-IDF, model training, and comprehensive evaluation.

| Item | Details |
|------|---------|
| **Task** | Binary Sentiment Classification |
| **Dataset** | Customer Reviews (2,000 samples — balanced) |
| **Vectorizer** | TF-IDF (Unigrams + Bigrams, 5,000 features) |
| **Model** | Logistic Regression |
| **Test Accuracy** | ~97%+ |
| **ROC-AUC** | ~0.99 |
| **Language** | Python 3.8+ |

---

## 📁 Project Structure

```
sentiment-analysis-nlp/
│
├── Sentiment_Analysis_NLP.ipynb         ← Main Jupyter Notebook (fully executed)
├── requirements.txt                     ← Python dependencies
├── README.md                            ← Project documentation
│
└── images/                              ← All generated visualizations
    ├── 01_eda_overview.png
    ├── 02_wordclouds.png
    ├── 03_tfidf_top_terms.png
    ├── 04_confusion_matrix.png
    ├── 05_roc_curve.png
    ├── 06_lr_coefficients.png
    ├── 07_learning_curve.png
    ├── 08_regularization_analysis.png
    └── 09_cross_validation.png
```

---

## 🔬 Notebook Sections

| # | Section | Description |
|---|---------|-------------|
| 1 | Import Libraries | All NLP and ML packages |
| 2 | Dataset Creation | 2,000 balanced customer reviews |
| 3 | EDA | Distribution, review length, word count analysis |
| 4 | Word Clouds | Positive & Negative visual word frequency |
| 5 | Text Preprocessing | Lowercase, clean, tokenise, stopword removal, lemmatisation |
| 6 | TF-IDF Vectorization | Feature extraction with unigrams + bigrams |
| 7 | Model Training | Logistic Regression with evaluation |
| 8 | Confusion Matrix | Prediction error analysis |
| 9 | ROC Curve | AUC-ROC visualization |
| 10 | LR Coefficients | Most influential words per sentiment |
| 11 | Learning Curve | Bias-variance trade-off |
| 12 | Regularization Analysis | Effect of C parameter on accuracy |
| 13 | Cross-Validation | 10-fold CV results |
| 14 | Live Predictions | Classify custom review text |
| 15 | Summary | Key findings & performance metrics |

---

## 📊 Visualizations

### EDA Overview
![EDA](images/01_eda_overview.png)

### Word Clouds
![Word Clouds](images/02_wordclouds.png)

### Top TF-IDF Terms
![TF-IDF Terms](images/03_tfidf_top_terms.png)

### Confusion Matrix
![Confusion Matrix](images/04_confusion_matrix.png)

### ROC Curve
![ROC Curve](images/05_roc_curve.png)

### Logistic Regression Coefficients
![LR Coefficients](images/06_lr_coefficients.png)

### Learning Curve
![Learning Curve](images/07_learning_curve.png)

### Regularization Analysis
![Regularization](images/08_regularization_analysis.png)

### Cross-Validation
![Cross Validation](images/09_cross_validation.png)

---

## ⚙️ Setup & Run

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/sentiment-analysis-nlp.git
cd sentiment-analysis-nlp
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Launch the Notebook
```bash
jupyter notebook Sentiment_Analysis_NLP.ipynb
```

> Also works in **VS Code**, **JupyterLab**, or **Google Colab**.

---

## 📦 Requirements

```
numpy
pandas
matplotlib
seaborn
scikit-learn
nltk
wordcloud
jupyter
nbformat
```

---

## 🔧 NLP Preprocessing Pipeline

```
Raw Text
   ↓  Lowercase Conversion
   ↓  Remove URLs, Numbers, Punctuation
   ↓  Tokenisation
   ↓  Stopword Removal  (NLTK English)
   ↓  Lemmatisation     (WordNetLemmatizer)
Cleaned Tokens
   ↓  TF-IDF Vectorization (5000 features, bigrams)
Feature Matrix  →  Logistic Regression  →  Sentiment Label
```

---

## 🔑 Key Findings

- **TF-IDF bigrams** effectively capture sentiment phrases like *"best purchase"*, *"worst product"*, and *"highly recommend"*.
- **Logistic Regression coefficients** are fully interpretable — words like *"amazing"*, *"fantastic"* strongly predict Positive; *"terrible"*, *"broken"*, *"disappointed"* predict Negative.
- The **learning curve** shows steady improvement with data size — the model is not overfitting.
- **Regularization analysis** confirms C=1.0 is a good default — too small underfits, too large overfits.
- **10-fold CV** confirms robust generalisation with consistent accuracy across folds.

---

## 📈 Model Performance

| Metric | Score |
|--------|-------|
| Test Accuracy | ~97%+ |
| ROC-AUC | ~0.99 |
| Precision (macro avg) | ~0.97 |
| Recall (macro avg) | ~0.97 |
| F1-Score (macro avg) | ~0.97 |
| 10-Fold CV Mean | ~95%+ |

---

## 🛠 Technologies Used

- **Python 3.8+**
- **Scikit-Learn** — TF-IDF, Logistic Regression, Pipeline, evaluation
- **NLTK** — Stopword removal, lemmatisation
- **WordCloud** — Visual word frequency
- **Matplotlib / Seaborn** — All visualizations
- **Pandas / NumPy** — Data handling
- **Jupyter Notebook** — Interactive analysis environment

---

## 📚 References

- [Scikit-Learn TF-IDF Docs](https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html)
- [NLTK Documentation](https://www.nltk.org/)
- Manning, C. et al. (2008). *Introduction to Information Retrieval*. Cambridge UP.
- Pang, B. & Lee, L. (2008). *Opinion Mining and Sentiment Analysis*. Now Publishers.

---

## 📄 License

This project is licensed under the **MIT License** — free to use and adapt.

---

*Made with 💬 Python · NLP · Scikit-Learn*
